import {Component} from 'react'

export default class ThirdComponent extends Component{
  render() {
    return (
      <div className="ThirdComponent">Third Component</div>
    )
  }
}